<?php
    $template = __DIR__.'/../templates';
    $jatbi = $app->getValueData('jatbi');
    $setting = $app->getValueData('setting');
    $account = $app->getValueData('account');
    $app->group("/proposal",function($app) use($setting,$jatbi, $common, $template,$account) {

    });
 ?>